# R.E. RoyalTrading Inc - CRM (WebService)
CRM App for Royal Trading running on Windows.
The project was based on old MyCheckpoint for Windows.

## Requirements
