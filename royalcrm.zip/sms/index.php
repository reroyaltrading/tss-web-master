<?php

header("location: https://blascke.com");