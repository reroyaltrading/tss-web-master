angular.module("InsightCRM").controller("DiallingController", function($scope, $http, $window){
    
    $scope.companies = {};
    $scope.is_locked = false;
    $scope.last_client_id;
    $scope.selector = {};

    $scope.loading_companies = true;
    $scope.loading_client = false;

    $scope.message_add = {};
    $scope.loading_client = false;

    $scope.LoadCompanies = function()
    {
        var json_url = base_url + "/api/companies/list";
        $http.get(json_url).success(function($data){
            $scope.companies = $data;
            $scope.loading_companies = false;
            console.log($scope.companies);
        });
    };

    $scope.CallClient = function()
    {
        var phone = $scope.current_client.phone;
        callbackObj.callClient(phone);
    };

    $scope.LoadHashes = function()
    {
        var json_url = base_url + "/api/companies/hashes?company_id=" + $scope.selector.company_id;
        $http.get(json_url).success(function($data){
            $scope.hashes = $data;
            console.log($scope.hashes);
        });
    };

    $scope.LoadStatuses = function()
    {
        var json_url = base_url + "/api/companies/statuses?company_id=" + $scope.selector.company_id + "&hash=" + $scope.selector.hash_stamp;
        $http.get(json_url).success(function($data){
            $scope.statuses = $data;
            console.log($scope.statuses);
        });
    };

    $scope.LoadScript = function()
    {
        var json_url = base_url + "/api/scripts/list?company_id=" + $scope.selector.company_id;
        $http.get(json_url).success(function($data){
            $scope.script = $data[0];
            $("#script_content").html($scope.script.content);
            console.log($scope.script);
        });
    };

    $scope.LoadNotes = function()
    {
        var json_url = base_url + "/api/clients/notes/list?id=" + $scope.current_client.id;
        $http.get(json_url).success(function($data){
            $scope.client_notes = $data;
            console.log($scope.client_notes);
        });
    };

    $scope.GetCompanyNoSelector = function()
    {
        var json_url = base_url + "/api/dialling/noselector";
        $http.get(json_url).success(function($data){
            $scope.selector = $data;
            console.log($scope.selector);
        });
    };

    $scope.CreateMessage = function()
    {
        var json_url = base_url + "/api/clients/sms/save";

        $scope.message_add.client_id = $scope.current_client.id;

        $http({
            method  : 'POST',
            url     : json_url,
            data    :  $.param($scope.message_add), 
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' } 
        }).success(function($data) {    
            $scope.SendSms($scope.current_client.phone, $scope.message_add.message_text);
            $scope.message_add.message_text = "";
            $scope.LoadSms();
        });
    };

    $scope.SendSms = function($phone, $message)
    {
        var json_url = base_url + "/sms/send.php";

        $scope.message_temp = {};
        $scope.message_temp.phone = $phone;
        $scope.message_temp.message = $message;

        $http({
            method  : 'POST',
            url     : json_url,
            data    :  $.param($scope.message_temp), 
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' } 
        }).success(function($data) {
            if($data.sent)
            {
                doSuccessMessage("SMS sent sucessfully");
            }else{
                doErrorMessage("SMS could not be sent");
            }
        });
    };

    $scope.UpdateClient = function($id)
    {
        var json_url = base_url + "/api/clients/get?id=" + $id;
        $http.get(json_url).success(function($data){
            $scope.current_client = $data;
        });
    }

    $scope.EditClient = function($id)
    {
        $scope.LoadCompanies();
        var json_url = base_url + "/api/clients/get?id=" + $id;
        $http.get(json_url).success(function($data){
            $scope.client = $data;
            console.log($scope.client);
            $("#modalEditClient").modal("show");
        });
    };

    $scope.CreateClient = function()
    {
        $scope.client = null;
        $("#modalEditClient").modal("show");
    };

    $scope.SaveClient = function()
    {
        var json_url = base_url + "/api/clients/save";

        $http({
            method  : 'POST',
            url     : json_url,
            data    :  $.param($scope.client), 
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' } 
        }).success(function($data) {
            if(!$data.created)
            {
                doErrorMessage("SMS could not be sent");
            }else{
                $("#modalEditClient").modal("hide");               
            }

            $scope.UpdateClient($scope.current_client.id);
        });
    };

    $scope.CreateNote = function()
    {
        var json_url = base_url + "/api/clients/notes/save";
        $scope.note_add.client_id = $scope.current_client.id;
        $scope.note_add.status_id = $scope.current_client.status_id;

        $http({
            method  : 'POST',
            url     : json_url,
            data    :  $.param($scope.note_add), 
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' } 
        }).success(function($data) {
            $scope.note_add.description = "";
            $scope.LoadNotes();
        });
    }

    $scope.LoadSms = function()
    {
        var json_url = base_url + "/api/clients/sms/list?client_id=" + $scope.current_client.id;
        $http.get(json_url).success(function($data){
            $scope.client_messages = $data;
            console.log($scope.client_messages);
        });
    };

    $scope.LoadAllStatuses = function()
    {
        var json_url = base_url + "/api/statuses/list";
        $http.get(json_url).success(function($data){
            $scope.all_statuses = $data;
            console.log($scope.all_statuses);
        });
    };

    $scope.UnlockClient = function($id)
    {
        var json_url = base_url + "/api/clients/unlockone?id=" + $id;
        $http.get(json_url).success(function($data){
            console.log($data);
        });
    };

    $scope.CloseSession = function()
    {
        if (typeof $scope.current_client !== 'undefined' && $scope.current_client != null)
        {
            $scope.UnlockClient($scope.current_client.id);
            $scope.is_locked = false;
        }
    };

    $scope.NextClient = function()
    {
        if (typeof $scope.current_client !== 'undefined' && $scope.current_client != null)
        {
            $scope.UnlockClient($scope.current_client.id);
        }

        var json_url = base_url + "/api/clients/nextclient";
        $scope.loading_client = true;
        $scope.selector.hash_stamp = $scope.selector.hash_import;

        $http({
            method  : 'POST',
            url     : json_url,
            data    :  $.param($scope.selector), 
            headers : { 'Content-Type': 'application/x-www-form-urlencoded' } 
        }).success(function($data) {

            $scope.is_locked = $data.found;
            $scope.current_client = $data.client;

            if(!$data.found)
            {
                //alert("No client found");
                doErrorMessage("No client found");
            }
            console.log($data);

            $scope.LoadScript();
            $scope.LoadNotes();
            $scope.LoadSms();

            $scope.loading_client = false;
        });
    }
});