<?php $__env->startSection('content'); ?>
   
<div class="" ng-controller="ClientController">
<div class="row" ng-hide="is_locked">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="form-element-list mg-t-30">
                <div class="cmp-tb-hd">
                    <h2><?php echo e($client->name); ?></h2>
                    <p>Select the company you're will be working with</p>
                </div>
                <!--<img ng-show="loading_companies" src="<?php echo e(asset('public/loading.gif')); ?>" />-->

                <hr>

                <div class="tab-ctn">
                        <p class="ng-binding"><strong>Name:</strong>&nbsp;<?php echo e($client->name); ?></p>
                        <p class="ng-binding"><strong>Email:</strong>&nbsp;<?php echo e($client->email); ?></p>
                        <p class="ng-binding"><strong>Phone:</strong>&nbsp;<?php echo e($client->phone); ?></p>
                        <p class="ng-binding"><strong>State/Province:</strong>&nbsp;<?php echo e($client->state_province); ?></p>
                        <p class="ng-binding"><strong>Import:</strong>&nbsp;<?php echo e($client->hash_import); ?></p>
                        <p class="tab-mg-b-0"><strong>Description:</strong>&nbsp;<?php echo e($client->description); ?></p>
                    </div>

                

                <?php if(count($messages) > 0): ?>
                    <hr>
                    <h3>Latest Messages</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Text</th>
                                    <th>Sent by</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($message->id); ?></td>
                                        <td><?php echo e($message->message_text); ?></td>
                                        <td><?php echo e($message->user_name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>


                    <?php if(count($notes) > 0): ?>
                    <hr>
                    <h3>Latest Notes</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Text</th>
                                    <th>Sent by</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($note->id); ?></td>
                                        <td><?php echo e($note->description); ?></td>
                                        <td><?php echo e($note->user_name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
            </div>
        </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\api.crmroyal.com\royalcrm\resources\views/client/info.blade.php ENDPATH**/ ?>