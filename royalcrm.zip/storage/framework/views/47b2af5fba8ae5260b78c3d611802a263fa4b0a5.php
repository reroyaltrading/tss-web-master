<?php $__env->startSection('content'); ?>

<div class="row mg-t-30" ng-controller="CalendarController">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="normal-table-list">
                <div class="basic-tb-hd">
                    <h2>Events</h2>
                    <p>Current events on system</p>
                </div>
                <div class="bsc-tbl" ng-init="LoadEvents()">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="table-responsive">
                                <table class="table table-stripped">
                                    <thead>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Client</th>
                                        <th>Operator</th>
                                    </thead>
                                    <tbody>
                                        <tr ng-repeat="event in events">
                                            <td><% $index+1 %></td>
                                            <td><% event.date_to_call %></td>
                                            <td><% event.client_name %></td>
                                            <td><% event.user_name %></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div id='calendar'></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
    <link href='<?php echo e(asset('public/fullcalendar/core/main.css')); ?>' rel='stylesheet' />
    <link href='<?php echo e(asset('public/fullcalendar/daygrid/main.css')); ?>' rel='stylesheet' />
    <script src='<?php echo e(asset('public/fullcalendar/core/main.js')); ?>'></script>
    <script src='<?php echo e(asset('public/fullcalendar/interaction/main.js')); ?>'></script>
    <script src='<?php echo e(asset('public/fullcalendar/daygrid/main.js')); ?>'></script>
    <script src="<?php echo e(asset('node_modules/angular-fullcalendar/src/angular-fullcalendar.js')); ?>"></script>

    <script src="<?php echo e(asset('public/scopes/CalendarController.js')); ?>"></script>

    <script>
            document.addEventListener('DOMContentLoaded', function() {
              var calendarEl = document.getElementById('calendar');      
              var calendar = new FullCalendar.Calendar(calendarEl, {
                plugins: [ 'dayGrid' ],
              });      

            calendar.on('dateClick', function(info) {
                console.log('clicked on ' + info.dateStr);
            });              

              calendar.render();
            });
      
          </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\api.crmroyal.com\royalcrm\resources\views/calendar/index.blade.php ENDPATH**/ ?>