<div id="dropzone_test"  method="post" style="border: 2px dashed #00c292; margin-top: 20px;" action="/upload" class="dropzone">
    <div class="fallback">
            <input name="file" type="file" />
          </div>

          <div class="dz-message needsclick download-custom">
                <i class="notika-icon notika-cloud"></i>
                <h2>Drop files here or click to upload.</h2>
                <p><span class="note needsclick">(This is just a demo dropzone. Selected files are <strong>not</strong> actually uploaded.)</span>
                </p>
            </div>
</div>